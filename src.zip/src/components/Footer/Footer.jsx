import React from "react";

export default function Footer() {
  return (
    <footer className="bg-gray-50 text-gray-700 pt-8 border-t border-gray-200">
      <div className="w-[90%] max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-6 py-6 text-sm">
        <div>
          <h4 className="font-semibold mb-3 text-gray-900">Customer Service</h4>
          <ul className="space-y-2 text-gray-600">
            <li><a href="#" className="hover:text-rose-600">Help Center</a></li>
            <li><a href="#" className="hover:text-rose-600">Shipping & Delivery</a></li>
            <li><a href="#" className="hover:text-rose-600">Returns</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3 text-gray-900">Shop</h4>
          <ul className="space-y-2 text-gray-600">
            <li><a href="#" className="hover:text-rose-600">Phones</a></li>
            <li><a href="#" className="hover:text-rose-600">Laptops</a></li>
            <li><a href="#" className="hover:text-rose-600">Accessories</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3 text-gray-900">Legal</h4>
          <ul className="space-y-2 text-gray-600">
            <li><a href="#" className="hover:text-rose-600">Privacy Policy</a></li>
            <li><a href="#" className="hover:text-rose-600">Terms</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3 text-gray-900">Contact</h4>
          <p className="text-gray-600 text-sm">support@shop.example</p>
          <p className="text-gray-600 text-sm mt-2">+995 77 44 88</p>
        </div>
      </div>

      <div className="w-[90%] max-w-6xl mx-auto text-center py-4 text-xs text-gray-500 border-t border-gray-100">
        © 2025 ULTRA. All rights reserved.
      </div>
    </footer>
  );
}
