import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { loginUser, setCurrentUser } from '../../Features/user/UserSlice';
import { useNavigate } from 'react-router-dom';

const UserLoginForm = ({ switchForm }) => {
  const [values, setValues] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleChange = ({ target: { name, value } }) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  const submit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const usernameGuess = values.email.includes('@') ? values.email.split('@')[0] : values.email;
      const payload = { username: usernameGuess, password: values.password };

      const result = await dispatch(loginUser(payload)).unwrap();
      dispatch(setCurrentUser(result));
      navigate('/');
    } catch (err) {
      setError(err?.message || err?.payload || 'Login failed — check your credentials');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white rounded-2xl shadow-md p-6">
      <h2 className="text-2xl font-extrabold text-center mb-4 text-gray-900">Sign In</h2>

      <form onSubmit={submit} className="flex flex-col gap-4" aria-live="polite">
        <label className="sr-only" htmlFor="email">Email</label>
        <input
          id="email"
          type="email"
          name="email"
          value={values.email}
          onChange={handleChange}
          placeholder="Email"
          required
          className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500"
          aria-label="Email"
        />

        <label className="sr-only" htmlFor="password">Password</label>
        <input
          id="password"
          type="password"
          name="password"
          value={values.password}
          onChange={handleChange}
          placeholder="Password"
          required
          className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500"
          aria-label="Password"
        />

        {error && <p className="text-red-500 text-sm text-center" role="alert">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="flex justify-center items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-2 rounded-2xl hover:from-blue-700 hover:to-indigo-700 transition disabled:opacity-60"
          aria-disabled={loading}
        >
          {/* CircularProgress left as-is (не меняю логику/импорты) */}
          {loading && <span className="w-4 h-4 inline-block animate-spin border-2 border-white/30 border-t-white rounded-full" aria-hidden="true" />}
          {loading ? 'Signing in...' : 'Sign In'}
        </button>
      </form>

      <p className="mt-4 text-center text-gray-600">
        Don’t have an account?{' '}
        <button
          type="button"
          onClick={() => switchForm?.('signup')}
          className="text-blue-600 font-medium hover:underline"
        >
          Sign up
        </button>
      </p>
    </div>
  );
};

export default UserLoginForm;
