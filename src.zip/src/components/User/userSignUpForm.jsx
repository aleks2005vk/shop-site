import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { createUser, loginUser, setCurrentUser } from '../../Features/user/UserSlice';
import { useNavigate } from 'react-router-dom';

const UserSignUpForm = ({ switchForm }) => {
  const [values, setValues] = useState({
    email: '',
    name: '',
    password: '',
    avatarFile: null,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [previewUrl, setPreviewUrl] = useState(null);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleChange = ({ target: { name, value } }) => {
    setValues(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files && e.target.files[0] ? e.target.files[0] : null;
    setValues(prev => ({ ...prev, avatarFile: file }));
  };

  // create/revoke preview URL safely
  useEffect(() => {
    if (!values.avatarFile) {
      setPreviewUrl(null);
      return;
    }
    const url = URL.createObjectURL(values.avatarFile);
    setPreviewUrl(url);
    return () => {
      URL.revokeObjectURL(url);
    };
  }, [values.avatarFile]);

  const submit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const username = values.name || (values.email ? values.email.split('@')[0] : '') || `user${Date.now()}`;
      const createPayload = {
        email: values.email,
        username,
        password: values.password,
        name: { firstname: values.name || username, lastname: '' },
      };

      const created = await dispatch(createUser(createPayload)).unwrap();

      try {
        const loginPayload = { username, password: values.password };
        const result = await dispatch(loginUser(loginPayload)).unwrap();

        if (result) {
          const userWithAvatar = {
            ...result,
            avatar: values.avatarFile ? values.avatarFile.name : result.avatar ?? null,
          };
          dispatch(setCurrentUser(userWithAvatar));
          navigate('/');
          return;
        }
      } catch {
        const fallbackUser = {
          id: created?.id ?? null,
          name: created?.name?.firstname ? `${created.name.firstname} ${created.name.lastname || ''}`.trim() : values.name || username,
          email: created?.email ?? values.email,
          username: created?.username ?? username,
          token: null,
          avatar: values.avatarFile ? values.avatarFile.name : null,
        };
        dispatch(setCurrentUser(fallbackUser));
        setError('Account created but automatic login failed — please sign in.');
        navigate('/');
        return;
      }
    } catch (err) {
      setError(err?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-[90%] max-w-md mx-auto bg-white rounded-2xl shadow-md p-6 mt-6">
      <h2 className="text-2xl font-extrabold text-center mb-4 text-gray-900">Create account</h2>

      <form onSubmit={submit} className="flex flex-col gap-4" aria-live="polite">
        <label className="sr-only" htmlFor="email">Email</label>
        <input
          id="email"
          type="email"
          name="email"
          value={values.email}
          onChange={handleChange}
          placeholder="Email"
          required
          className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500"
          aria-label="Email"
        />

        <label className="sr-only" htmlFor="name">Name</label>
        <input
          id="name"
          type="text"
          name="name"
          value={values.name}
          onChange={handleChange}
          placeholder="Name"
          required
          className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500"
          aria-label="Full name"
        />

        <label className="sr-only" htmlFor="password">Password</label>
        <input
          id="password"
          type="password"
          name="password"
          value={values.password}
          onChange={handleChange}
          placeholder="Password"
          required
          className="px-4 py-3 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500"
          aria-label="Password"
        />

        {/* Avatar upload */}
        <div className="flex items-center gap-4">
          <label
            htmlFor="avatar"
            className="inline-flex items-center gap-3 px-4 py-2 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white cursor-pointer hover:opacity-95 transition"
          >
            <span className="text-sm font-medium">Upload Avatar</span>
            <input
              id="avatar"
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
              aria-label="Upload avatar image"
            />
          </label>

          {previewUrl ? (
            <img
              src={previewUrl}
              alt="Avatar preview"
              className="w-12 h-12 rounded-full object-cover border border-gray-200"
            />
          ) : (
            <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 text-sm">
              JPG
            </div>
          )}
        </div>

        {error && (
          <p className="text-red-500 text-sm text-center" role="alert">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={loading}
          className="flex justify-center items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 rounded-2xl hover:from-blue-700 hover:to-indigo-700 transition disabled:opacity-60"
          aria-disabled={loading}
        >
          {loading && (
            <span
              className="w-4 h-4 inline-block animate-spin border-2 border-white/30 border-t-white rounded-full"
              aria-hidden="true"
            />
          )}
          {loading ? 'Creating account...' : 'Sign Up'}
        </button>
      </form>

      <p className="mt-4 text-center text-gray-600">
        Already have an account?{' '}
        <button
          className="text-blue-600 font-medium hover:underline"
          onClick={() => switchForm?.('login')}
          type="button"
        >
          Sign in
        </button>
      </p>
    </div>
  );
};

export default UserSignUpForm;
