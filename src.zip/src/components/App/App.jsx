import React, { useEffect } from 'react';
import AppRoutes from './Routes/Routes';
import Header from '../Header/Header';
import Footer from '../Footer/Footer';
import { useDispatch } from 'react-redux';
import { getCategories } from "../../Features/Categories/categoriesSlice";
import { getProducts } from '../../Features/Products/productsSlice';

const App = () => {
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(getCategories());
        dispatch(getProducts());
    }, [dispatch]);

    return (
        <div className="app" sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
            <Header />
            <div component="main" sx={{ flexGrow: 1 }}>
                <AppRoutes />
            </div>
            <Footer />
        </div>
    );
};

export default App;