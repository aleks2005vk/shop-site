import React, { useEffect } from 'react';
import { Poster } from '../../poster/poster';
import Products from '../../Products/Products';
import { useSelector, useDispatch } from 'react-redux';
import Categories from '../../Categories/Categories';

import { getProducts } from '../../../Features/Products/productsSlice';
import { getCategories } from '../../../Features/Categories/categoriesSlice';

const Home = () => {
    const { items, filtered } = useSelector(state => state.products);
    const { categories } = useSelector(state => state.categories);
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(getProducts());
        dispatch(getCategories());
    }, [dispatch]);

    useEffect(() => {
        if (!items || items.length === 0) return;
        dispatch({ type: 'products/filterByPrice', payload: 100 });
    }, [dispatch, items]);

    return (
        <section className="home-section bg-gray-50">
            <div className="w-[90%] max-w-6xl mx-auto px-4 py-12 space-y-12">
                {/* Poster */}
                <div className="poster-wrapper bg-transparent">
                    <Poster />
                </div>

                {/* Trending */}
                <div className="trending-products">
                    <h2
                      className="text-3xl md:text-4xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600"
                      aria-label="Trending products"
                    >
                        Trending
                    </h2>
                    <div className="grid">
                      <Products Products={items} amount={5} />
                    </div>
                </div>

                {/* Categories */}
                <div className="categories-section">
                    <h2
                      className="text-3xl md:text-4xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600"
                      aria-label="Categories"
                    >
                        Categories
                    </h2>
                    <div className="grid">
                      <Categories products={categories} amount={5} />
                    </div>
                </div>

                {/* Less than $100 */}
                <div className="less-than-100">
                    <h2
                      className="text-3xl md:text-4xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600"
                      aria-label="Products under 100 dollars"
                    >
                        Less than $100
                    </h2>
                    <div className="grid">
                      <Products Products={filtered} amount={5} />
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Home;
