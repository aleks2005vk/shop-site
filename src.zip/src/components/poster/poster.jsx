import React from 'react';

export const Poster = () => {
  return (
    <section
      role="banner"
      aria-label="Promotional poster"
      className="w-[90%] max-w-6xl mx-auto relative h-[420px] md:h-[520px] rounded-lg overflow-hidden"
    >
      {/* background image muted */}
      <img
        src="https://images.unsplash.com/photo-1612831455541-2c1e292a7f57?auto=format&fit=crop&w=1470&q=60"
        alt="Poster Background"
        className="absolute inset-0 w-full h-full object-cover filter grayscale-0 brightness-90"
        loading="lazy"
      />

      {/* overlay light */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-white/80" />

      <div className="relative z-10 h-full flex flex-col justify-center items-start px-6 md:px-12 text-gray-900 max-w-4xl">
        <span className="uppercase tracking-wider text-xs text-gray-600 mb-2">THE BEST SELLER OF 2025</span>

        <h1 className="text-3xl md:text-5xl lg:text-6xl font-extrabold mb-4 leading-tight text-gray-900">
          LENNON r2d2 WITH NVIDIA 5090TI
        </h1>

        <p className="text-sm md:text-base mb-6 text-gray-700 max-w-lg">
          Upgrade your gaming setup with the ultimate powerhouse GPU and refined minimalist design.
        </p>

        <div className="flex gap-3">
          <button className="px-5 py-3 rounded-md bg-rose-600 text-white font-medium hover:bg-rose-700 transition-shadow shadow-sm">
            Shop Now
          </button>
          <a href="#featured" className="text-sm text-gray-700 self-center">See featured</a>
        </div>
      </div>
    </section>
  );
};

export default Poster;
