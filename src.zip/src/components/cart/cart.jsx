import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { removeFromCart, increaseQuantity, decreaseQuantity } from '../../Features/user/UserSlice';

const Cart = () => {
  const dispatch = useDispatch();
  const { cart } = useSelector(state => state.user);

  const totalPrice = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  if (!cart || cart.length === 0) {
    return (
      <div className="w-[90%] max-w-4xl mx-auto p-8 text-center">
        <h2 className="text-2xl font-semibold text-gray-800">Your cart is empty</h2>
      </div>
    );
  }

  return (
    <div className="w-[90%] max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-6 text-gray-900">Your Cart</h1>

      <div className="space-y-4">
        {cart.map(item => (
          <div key={item.id} className="flex items-center gap-4 border border-gray-100 rounded-md p-4 bg-white">
            <img src={item.images && item.images.length > 0 ? item.images[0] : item.image || 'https://picsum.photos/80'} alt={item.title} className="w-20 h-20 object-cover rounded-md" />
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-gray-900 truncate">{item.title}</h3>
              {item.size && <p className="text-gray-500 text-sm">Size: {item.size}</p>}
              {item.category && <p className="text-gray-500 text-sm">{item.category}</p>}
              <p className="text-gray-800 font-medium mt-1">${item.price}</p>
            </div>

            <div className="flex items-center gap-2">
              <button onClick={() => dispatch(decreaseQuantity(item.id))} className="w-8 h-8 grid place-items-center border rounded-md hover:bg-gray-50">−</button>
              <span>{item.quantity}</span>
              <button onClick={() => dispatch(increaseQuantity(item.id))} className="w-8 h-8 grid place-items-center border rounded-md hover:bg-gray-50">+</button>
            </div>

            <button onClick={() => dispatch(removeFromCart(item.id))} className="ml-4 text-rose-600 hover:text-rose-700">Remove</button>
          </div>
        ))}
      </div>

      <div className="mt-6 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <h2 className="text-lg font-semibold text-gray-900">Total: ${totalPrice.toFixed(2)}</h2>
        <button className="px-6 py-2 rounded-md bg-rose-600 text-white hover:bg-rose-700">Proceed to Checkout</button>
      </div>
    </div>
  );
};

export default Cart;
