import React, { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { toggleForm, logout } from '../../Features/user/UserSlice';
import UserForm from '../User/userform';
import { useGetProductsQuery } from '../../Features/api/ApiSlice';
import {
  DevicePhoneMobileIcon,
  ComputerDesktopIcon,
  SpeakerWaveIcon,
  CameraIcon,
  ClockIcon,
  TagIcon,
  MagnifyingGlassIcon,
  ShoppingCartIcon,
} from '@heroicons/react/24/outline';

export default function Header() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { currentUser, showForm } = useSelector((state) => state.user);
  const items = useSelector((state) => state.categories.items || []);
  const { data: allProducts = [], isLoading, error } = useGetProductsQuery();

  const toggleDrawer = () => setDrawerOpen((s) => !s);
  const handleProfileClick = () => !currentUser?.name && dispatch(toggleForm(true));
  const handleCloseModal = () => dispatch(toggleForm(false));
  const handleLogout = () => { dispatch(logout()); dispatch(toggleForm(false)); navigate('/'); };

  const displayName = typeof currentUser?.name === 'string'
    ? currentUser.name
    : currentUser?.name
      ? `${currentUser.name.firstname ?? ''} ${currentUser.name.lastname ?? ''}`.trim()
      : '';

  const filteredProducts = useMemo(() => {
    if (!searchValue) return [];
    const q = searchValue.toLowerCase();
    return allProducts.filter((p) => (p.title || '').toLowerCase().includes(q));
  }, [allProducts, searchValue]);

  return (
    <header className="sticky top-0 z-50">
      {/* thin top info bar */}
      <div className="bg-gray-50 border-b border-gray-200 text-sm text-gray-600">
        <div className="w-[90%] max-w-6xl mx-auto flex items-center justify-between py-2">
          <div>Call us: +995 77 44 88</div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:block">English</div>
            <div className="hidden sm:block">My Account</div>
          </div>
        </div>
      </div>

      {/* main navbar */}
      <div className="bg-white border-b border-gray-200">
        <div className="w-[90%] max-w-6xl mx-auto flex items-center justify-between py-4 gap-4">
          <div className="flex items-center gap-6">
            <button
              onClick={toggleDrawer}
              aria-label="Open menu"
              className="p-2 rounded-md hover:bg-gray-100 transition"
            >
              <svg className="w-5 h-5 text-gray-700" viewBox="0 0 24 24" fill="none"><path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
            </button>

            <div onClick={() => navigate('/')} className="flex items-center gap-3 cursor-pointer">
              <img src="/logo192.png" alt="Logo" className="w-10 h-10 object-contain" />
              <div className="hidden md:block">
                <div className="text-lg font-bold text-gray-900">ULTRA</div>
                <div className="text-xs text-gray-500 -mt-0.5">Marketplace</div>
              </div>
            </div>
          </div>

          {/* search */}
          <div className="flex-1 px-4 max-w-2xl">
            <div className="relative">
              <span className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                <MagnifyingGlassIcon className="w-5 h-5 text-gray-400" />
              </span>
              <input
                type="text"
                placeholder="Search products, brands, categories"
                className="w-full pl-10 pr-4 py-2 rounded-md border border-gray-200 bg-white focus:outline-none focus:ring-2 focus:ring-rose-200"
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                aria-label="Search"
              />
              {searchValue && (
                <div className="absolute left-0 right-0 mt-2 bg-white border border-gray-100 rounded-md shadow-sm z-40">
                  <div className="p-3 text-sm text-gray-500 flex items-center justify-between border-b border-gray-100">
                    <div>Results for <span className="font-medium text-gray-800">"{searchValue}"</span></div>
                    <button onClick={() => setSearchValue('')} className="text-xs text-gray-400">Clear</button>
                  </div>
                  <div className="max-h-56 overflow-y-auto">
                    {isLoading && <div className="p-4 text-gray-500">Loading...</div>}
                    {error && <div className="p-4 text-red-500">Error</div>}
                    {filteredProducts.map(p => (
                      <Link
                        key={p.id}
                        to={`/products/${p.id}`}
                        onClick={() => setSearchValue('')}
                        className="flex items-center gap-3 px-3 py-2 hover:bg-gray-50"
                      >
                        <div className="w-10 h-10 bg-gray-100 rounded-md bg-cover" style={{ backgroundImage: `url(${p.image || (p.images && p.images[0])})` }} />
                        <div className="flex-1 min-w-0">
                          <div className="text-sm text-gray-800 truncate">{p.title}</div>
                          <div className="text-xs text-gray-500 truncate">{p.category || ''}</div>
                        </div>
                        <div className="text-sm text-rose-600 font-semibold">{p.price ? `${p.price} ₾` : ''}</div>
                      </Link>
                    ))}
                    {filteredProducts.length === 0 && !isLoading && <div className="p-4 text-gray-500">No results</div>}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* right actions */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/cart')}
              className="relative p-2 rounded-md hover:bg-gray-100 transition"
              aria-label="Open cart"
            >
              <ShoppingCartIcon className="w-6 h-6 text-gray-700" />
              <span className="absolute -top-1 -right-1 bg-rose-600 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                {currentUser?.cart?.length ?? 0}
              </span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={handleProfileClick}
                className="w-9 h-9 rounded-full border border-gray-200 flex items-center justify-center text-gray-700 hover:bg-gray-50"
              >
                {displayName ? displayName[0].toUpperCase() : <svg className="w-5 h-5 text-gray-500" viewBox="0 0 24 24" fill="none"><path d="M12 12c2.761 0 5-2.239 5-5s-2.239-5-5-5-5 2.239-5 5 2.239 5 5 5zM3 21c0-3.866 3.582-7 9-7s9 3.134 9 7v1H3v-1z" fill="currentColor"/></svg>}
              </button>

              {displayName && <div className="hidden md:block text-sm text-gray-700">{displayName}</div>}
              {displayName && <button onClick={handleLogout} className="text-sm text-gray-600 hover:text-gray-800">Log out</button>}
            </div>
          </div>
        </div>
      </div>

      {/* drawer */}
      <div className={`fixed inset-0 z-50 ${drawerOpen ? '' : 'pointer-events-none'}`}>
        <div className={`absolute inset-0 bg-black/40 transition-opacity ${drawerOpen ? 'opacity-100' : 'opacity-0'}`} onClick={toggleDrawer} />
        <aside className={`absolute left-0 top-0 bottom-0 w-72 bg-white border-r border-gray-200 shadow-lg transform transition-transform ${drawerOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="p-4">
            <div className="text-lg font-semibold mb-3">Categories</div>
            <nav>
              <ul className="space-y-2">
                {items.map((cat, i) => (
                  <li key={cat}>
                    <Link to={`/categories/${cat.toLowerCase()}`} onClick={toggleDrawer} className="flex items-center gap-3 p-2 rounded-md hover:bg-gray-50">
                      <div className="w-8 h-8 bg-rose-50 text-rose-600 rounded-md flex items-center justify-center">{/* icon placeholder */}</div>
                      <div className="text-sm text-gray-800">{cat}</div>
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
        </aside>
      </div>

      <UserForm open={showForm} onClose={handleCloseModal} initial="signup" />
    </header>
  );
}
