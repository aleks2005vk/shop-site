import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useGetProductsQuery } from '../../Features/api/ApiSlice';

const Category = () => {
  const { id } = useParams();
  const [filter, setFilter] = useState('');

  const { data: products, isLoading } = useGetProductsQuery({ category: id });

  const filteredProducts = products?.filter(product =>
    product.title.toLowerCase().includes(filter.toLowerCase())
  );

  if (isLoading) return <p className="text-center py-8">Loading...</p>;

  return (
    <section className="w-[90%] max-w-6xl mx-auto px-4 md:px-8 py-8">
      <h2 className="text-3xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
        {products?.[0]?.category || 'Category'}
      </h2>

      {/* Фильтр */}
      <form
        className="mb-6 flex justify-center"
        onSubmit={e => e.preventDefault()}
      >
        <input
          type="text"
          name="title"
          placeholder="Search Product..."
          value={filter}
          onChange={e => setFilter(e.target.value)}
          className="border border-gray-300 rounded-2xl p-3 w-full max-w-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          aria-label="Search products in category"
        />
      </form>

      {/* Сетка продуктов */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {filteredProducts?.map(product => (
          <div
            key={product.id}
            className="bg-white shadow-md rounded-2xl overflow-hidden hover:shadow-xl transition transform hover:-translate-y-0.5"
            role="article"
            aria-label={product.title}
          >
            <div className="w-full h-48 overflow-hidden">
              <img
                src={product.images?.[0] || 'https://picsum.photos/300/300'}
                alt={product.title}
                className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300"
                loading="lazy"
              />
            </div>
            <div className="p-4 text-center">
              <h3 className="text-lg font-semibold text-gray-900 truncate">{product.title}</h3>
              <p className="text-blue-600 font-bold mt-2">${product.price}</p>
            </div>
          </div>
        ))}

        {!filteredProducts || filteredProducts.length === 0 && (
          <p className="col-span-full text-center text-gray-500 py-8">
            No products found.
          </p>
        )}
      </div>
    </section>
  );
};

export default Category;
