// src/components/Categories/SingleCategory.jsx
import React from 'react';
import { Poster } from '../poster/poster';
import Category from './Category';

const SingleCategory = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Poster />
      <Category />
    </div>
  );
};

export default SingleCategory;
