import React from 'react';
import { Link } from 'react-router-dom';

const Categories = ({ products = [], amount = 5, title = 'Categories' }) => {
  const list = products.slice(0, amount);

  if (!list || list.length === 0) {
    return (
      <section className="w-[90%] max-w-6xl mx-auto px-4 md:px-8 py-8">
        <h2 className="text-3xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
          {title}
        </h2>
        <p className="text-gray-500">No categories found.</p>
      </section>
    );
  }

  return (
    <section className="w-[90%] max-w-6xl mx-auto px-4 md:px-8 py-8">
      <h2 className="text-3xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
        {title}
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
        {list.map(({ id, name, image }) => (
          <Link
            to={`/categories/${id}`}
            key={id}
            className="block bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition transform hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-blue-200"
            aria-label={`Open category ${name}`}
          >
            <div className="w-full h-40 overflow-hidden">
              <img
                src={image || 'https://picsum.photos/300/300'}
                alt={name}
                className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300"
                loading="lazy"
              />
            </div>
            <div className="p-4 text-center">
              <h3 className="text-lg font-semibold text-gray-900 truncate">{name}</h3>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
};

export default Categories;
