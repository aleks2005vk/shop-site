import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ROUTES } from '../../utils/routes';
import { addToCart } from '../../Features/user/UserSlice';
import { useDispatch } from 'react-redux';

const SIZES = ['S', 'M', 'L', 'XL'];

const Product = ({ id, _id, title, price, description, images = [] }) => {
  const [currentImage, setCurrentImage] = useState(images.length > 0 ? images[0] : 'https://picsum.photos/600/400');
  const [currentSize, setCurrentSize] = useState(SIZES[0]);
  const dispatch = useDispatch();

  useEffect(() => { if (images.length > 0) setCurrentImage(images[0]); }, [images]);

  const handleAddToCart = () => {
    const productId = id ?? _id;
    const payload = { id: productId, title, price, description, images, size: currentSize, quantity: 1 };
    dispatch(addToCart(payload));
  };

  return (
    <section className="w-[90%] max-w-6xl mx-auto p-6 bg-white border border-gray-100 rounded-lg shadow-sm">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-1/2">
          <div className="w-full h-72 bg-gray-50 rounded-lg overflow-hidden">
            <img src={currentImage} alt={title} className="w-full h-full object-cover" loading="lazy" />
          </div>

          <div className="mt-3 flex gap-2">
            {(images.length > 0 ? images : ['https://picsum.photos/100/100']).map((img, i) => (
              <button key={i} onClick={() => setCurrentImage(img)} className="w-12 h-12 rounded-md overflow-hidden border border-gray-100">
                <img src={img} alt={`thumb-${i}`} className="w-full h-full object-cover" loading="lazy" />
              </button>
            ))}
          </div>
        </div>

        <div className="md:w-1/2 flex flex-col justify-between">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">{title}</h2>
            <p className="text-gray-600 mt-2">{description}</p>
            <div className="mt-4 text-2xl font-bold text-rose-600">${price ?? 'N/A'}</div>

            <div className="mt-4">
              <div className="text-sm text-gray-700 font-medium mb-2">Size</div>
              <div className="flex gap-2">
                {SIZES.map(s => (
                  <button
                    key={s}
                    onClick={() => setCurrentSize(s)}
                    className={`px-3 py-1 rounded-md border ${currentSize === s ? 'border-rose-500 bg-rose-50' : 'border-gray-200 bg-white'}`}
                    aria-pressed={currentSize === s}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6 flex items-center gap-3">
            <button onClick={handleAddToCart} className="px-5 py-2 bg-rose-600 text-white rounded-md hover:bg-rose-700 transition">
              Add to cart
            </button>
            <button className="px-4 py-2 border border-gray-200 rounded-md hover:bg-gray-50">Favorite</button>
            <div className="ml-auto text-sm text-gray-500">19 purchased</div>
          </div>

          <div className="mt-4">
            <Link to={ROUTES.HOME} className="text-sm text-gray-700 hover:underline">Return to store</Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Product;
