import React from 'react';
import { Link } from 'react-router-dom';
import { ROUTES } from '../../utils/routes';

const Products = ({ Products = [], amount = 5, title = 'Products' }) => {
  const items = Products.slice(0, amount);

  return (
    <section className="w-[90%] max-w-6xl mx-auto py-8">
      {title && <h2 className="text-2xl md:text-3xl font-semibold mb-6 text-gray-900">{title}</h2>}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {items.map((it) => {
          const id = it.id ?? it._id;
          const images = it.images ?? [];
          const titleText = it.title ?? 'No Title';
          const cat = typeof it.category === 'string' ? it.category : it.category?.name;
          const price = it.price;

          return (
            <Link
              to={ROUTES.PRODUCT.replace(':id', id)}
              key={id}
              className="bg-white border border-gray-100 rounded-lg shadow-sm overflow-hidden hover:shadow-md transition"
            >
              <div className="w-full h-44 overflow-hidden bg-gray-50">
                <img
                  src={images && images.length > 0 ? images[0] : 'https://picsum.photos/400/400'}
                  alt={titleText}
                  className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
              </div>

              <div className="p-4">
                <h3 className="text-md font-medium text-gray-900 truncate">{titleText}</h3>
                <div className="text-sm text-gray-500 mt-1">{cat || 'No Category'}</div>

                <div className="mt-3 flex items-center justify-between">
                  <div className="text-rose-600 font-semibold">${price ?? 'N/A'}</div>
                  <div className="text-gray-400 text-sm line-through">{price ? `${Math.floor(price * 1.2)}$` : 'N/A'}</div>
                </div>

                <div className="mt-2 text-xs text-gray-500">{Math.floor(Math.random() * 20 + 1)} purchased</div>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
};

export default Products;
