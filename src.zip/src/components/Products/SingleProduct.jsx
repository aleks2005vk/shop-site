import React, { useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useGetProductByIdQuery } from '../../Features/api/ApiSlice';
import { ROUTES } from '../../utils/routes';
import Product from './Product';
import Products from './Products';
import { useDispatch, useSelector } from 'react-redux';
import { getRelatedProducts } from '../../Features/Products/productsSlice';

const SingleProduct = () => {
  const dispatch = useDispatch();
  const { id } = useParams();
  const navigate = useNavigate();
  const { items, related } = useSelector(state => state.products || { items: [], related: [] });

  const { data: product, isLoading, isError } = useGetProductByIdQuery(id);

  useEffect(() => {
    if (isError) navigate(ROUTES.HOME);
  }, [isError, navigate]);

  useEffect(() => {
    if (!product || !items || items.length === 0) return;
    const pid = product.id ?? product._id;
    if (pid) dispatch(getRelatedProducts(pid));
  }, [product, items, dispatch]);

  useEffect(() => {
    if (!isLoading && !product) {
      navigate(ROUTES.HOME);
    }
  }, [isLoading, product, navigate]);

  if (isLoading) return <p className="text-center py-8 text-gray-500">Loading...</p>;
  if (!product) return null;

  const images =
    product.images && product.images.length > 0
      ? product.images
      : product.image
      ? [product.image]
      : [];

  const currentId = product.id ?? product._id;
  const relatedWithoutCurrent = (related || []).filter(p => (p.id ?? p._id) !== currentId);
  const relatedList = [product, ...relatedWithoutCurrent];

  return (
    <main className="w-[90%] max-w-6xl mx-auto py-8">
      <Product
        id={currentId}
        title={product.title}
        description={product.description}
        price={product.price}
        images={images}
      />

      {/* Related products */}
      {relatedList.length > 1 && (
        <section className="mt-12">
          <h3 className="text-2xl md:text-3xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
            Related Products
          </h3>

          <div aria-label="Related products">
            <Products Products={relatedList.slice(1)} amount={relatedList.length - 1} title="" />
          </div>
        </section>
      )}
    </main>
  );
};

export default SingleProduct;
